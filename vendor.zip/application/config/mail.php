<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    $config['mail'] = array(
      'protocol' => 'smtp',
      'smtp_host' => 'mail.smtp2go.com',
      'smtp_user' => 'httpss',
      'smtp_pass' => '!123master',
      'smtp_port' => 465,
      'mailtype' => 'html',
      'charset' => 'utf-8'
    );

    $config['addreas'] = 'panitia@himatif-https.tech';
?>